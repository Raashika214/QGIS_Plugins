from .dataReader import DataReader
from .imputePixels import ImputeMissingPixels
import pyswarms as ps
from .optimizationFunction import OptimizationFunction
import numpy as np
from .changesModulation import ChangesModulation
from multiprocessing import Manager, Process, Pool
import time
np.random.seed(100)

class IHISTIF:
    """
    Contains implementation of different fusion algorithms
    """

    def __init__(self,coarse_image_t0, coarse_image_t1, fine_image_t0, file_type = "geotiff"):
        """
        Initialize with the file reading 
        """
        self.coarse_image_t0 = coarse_image_t0
        self.coarse_image_t1 = coarse_image_t1
        self.fine_image_t0 = fine_image_t0
        self.process_pool = []

        # if(file_type == "geotiff"):
        #     """
        #     File Reading for GeoTIFF files
        #     """
        #     print("reading files")
        #     self.coarse_image_t0 = DataReader().read_geotiff_file(coarse_image_t0)
        #     self.coarse_image_t1 = DataReader().read_geotiff_file(coarse_image_t1)
        #     self.fine_image_t0 = DataReader().read_geotiff_file(fine_image_t0)

        # if(file_type == "tiff"):
        #     """
        #     File Reading for TIFF files
        #     """
        #     self.coarse_image_t0 = DataReader().read_tiff_file(coarse_image_t0)
        #     self.coarse_image_t1 = DataReader().read_tiff_file(coarse_image_t1)
        #     self.fine_image_t0 = DataReader().read_tiff_file(fine_image_t0)

        # if(file_type == "numpy"):
        #     """
        #     File Reading for numpy files
        #     """
        #     self.coarse_image_t0 = DataReader().read_numpy_file(coarse_image_t0)
        #     self.coarse_image_t1 = DataReader().read_numpy_file(coarse_image_t1)
        #     self.fine_image_t0 = DataReader().read_numpy_file(fine_image_t0)

        # Missing Pixel Imputation Initializer
        self.coarse_t0_impute = ImputeMissingPixels(self.coarse_image_t0)
        self.fine_t0_impute = ImputeMissingPixels(self.fine_image_t0)
        self.coarse_t1_impute = ImputeMissingPixels(self.coarse_image_t1)

    def process_band_fusion(self, band_num, opt_params, band_vals, optimizer_params, evaluation, optimizer = "default"):
        """
        Contains all the related operations required for prediction of each band
        Args:
            band_num (_int_): _The band number which is being processed_
            opt_params (_dict_): _Dict which stores all the optimal parameters for each band_
            band_vals (_dict_): _Dict which stores all the pred band values for each band_
            optimizer (_PSO_): _PSO optimizer which is used for optimization_
            kwargs (_dict_): _Dictionary containing all the parameters for optimizer_
            iterations (_int_): _Number of maximum iterations for reaching the optimal condition_
            evaluation (_bool_): _Mode in which the current processing is being done_
        """
        np.random.seed(100)

        bounds = optimizer_params["bounds"]
        kwargs = optimizer_params["kwargs"]
        iterations = optimizer_params["iterations"]
        variant = optimizer_params["variant"]

        options = {'c1': 2.0, 'c2': 2.0, 'w': 0.6}

        if(optimizer == "svd"):
            optimizer = ps.single.GlobalBestPSO(n_particles=30, dimensions=5, options=options, bounds=bounds)
            cost, optimized_params = optimizer.optimize(OptimizationFunction().optima_SVD, iters = iterations, **kwargs)

        elif(optimizer == "vgg"):
            del kwargs['n_components']
            optimizer = ps.single.GlobalBestPSO(n_particles=50, dimensions=5, options=options, bounds=bounds)
            cost, optimized_params = optimizer.optimize(OptimizationFunction().optima_VGG16, iters = iterations, **kwargs)
        
        elif(optimizer == "pca"):
            optimizer = ps.single.GlobalBestPSO(n_particles=50, dimensions=5, options=options, bounds=bounds)
            cost, optimized_params = optimizer.optimize(OptimizationFunction().optima_PCA, iters = iterations, **kwargs)

        else:
            del kwargs['n_components']
            optimizer = ps.single.GlobalBestPSO(n_particles=50, dimensions=5, options=options, bounds=bounds)
            cost, optimized_params = optimizer.optimize(OptimizationFunction().optima, iters = iterations, **kwargs)

        opt_params[band_num] = [cost, optimized_params]

        # Modulation of changes
        coarse_t0_psf = OptimizationFunction().FFT(optimized_params, kwargs['coarse_image'], kwargs['edge'], kwargs['N'])

        # For avoiding floating precision errors
        modified_params = np.rint(optimized_params)
        coarse_t1_psf = OptimizationFunction().FFT(modified_params, self.coarse_image_t1[:, :, band_num], kwargs['edge'], kwargs['N'])
        coarse_t0_psf_mod = OptimizationFunction().FFT(modified_params, kwargs['coarse_image'], kwargs['edge'], kwargs['N'])

        # use for evaluation against changes in modulation method
        if(evaluation == True):
            pred_fine_t1_histif = ChangesModulation().multiplicativeModulation(coarse_t0_psf, coarse_t1_psf, kwargs["fine_image"], variant = 'old', coarse_t0_psf_mod = coarse_t0_psf_mod)
            pred_fine_t1_ihistif = ChangesModulation().multiplicativeModulation(coarse_t0_psf, coarse_t1_psf, kwargs["fine_image"], variant = 'new', coarse_t0_psf_mod = coarse_t0_psf_mod)
            pred_fine_t1_new = ChangesModulation().svm_modulation(coarse_t0_psf.reshape(kwargs['N'], kwargs['N']), coarse_t1_psf.reshape(kwargs['N'], kwargs['N']), kwargs["fine_image"].reshape(kwargs['N'], kwargs['N']), variant = 'new', coarse_t0_psf_mod = coarse_t0_psf_mod)
            pred_fine_t1_histif = pred_fine_t1_histif.reshape(kwargs['N'], kwargs['N'])
            pred_fine_t1_ihistif = pred_fine_t1_ihistif.reshape(kwargs['N'], kwargs['N'])
            pred_fine_t1_new = pred_fine_t1_new.reshape(kwargs['N'], kwargs['N'])
            band_vals[band_num] = [pred_fine_t1_histif, pred_fine_t1_ihistif, pred_fine_t1_new]

        # used for normal running of any varaint of algo
        else:
            pred_fine_t1 = ChangesModulation().multiplicativeModulation(coarse_t0_psf, coarse_t1_psf, kwargs["fine_image"], variant = variant, coarse_t0_psf_mod = coarse_t0_psf_mod)      
            pred_fine_t1 = pred_fine_t1.reshape(kwargs['N'], kwargs['N'])
            band_vals[band_num] = pred_fine_t1

    def fusion(self, parameters, iterations, neighbours = 4, evaluation = False, variant = 'new', optimizer = "default", n_components = 10):
        """
        Start fusion process for predicting fine t1 image
        Args:
            parameters (_list_): _List of list containing PSF and Fusion parameters_
            iterations (_int_): _Iterations to be used for optimization process_
            neighbours (int, optional): _Neighbours to consider for missing pixels_. Defaults to 4.
            evaluation (bool, optional): _To run simulataneous algos for eval mode_. Defaults to False.
            variant (str, optional): _For specifying varaint of algo to use_. Defaults to 'new'.

        Returns:
            _list_: _cost values and parameters, list of predisted bands_
        """

        # Impute Missing Values
        print("Processing imputation for Coarse t0 image...")
        self.coarse_image_t0 = self.coarse_t0_impute.using_nn_weighted_average(neighbours = neighbours)
        
        print("Processing imputation for Coarse t1 image...")
        self.coarse_image_t1 = self.coarse_t1_impute.using_nn_weighted_average(neighbours = neighbours)

        print("Processing imputation for Fine t0 image...")
        self.fine_image_t0 = self.fine_t0_impute.using_nn_weighted_average(neighbours = neighbours)
        
        # Particle Swarm Optimization for alignment
        lower_bound = np.array([parameters[0][0], parameters[1][0], parameters[2][0], parameters[3][0], parameters[4][0]])
        upper_bound = np.array([parameters[0][1], parameters[1][1], parameters[2][1], parameters[3][1], parameters[4][1]])
        bounds = (lower_bound, upper_bound)
        edge = (self.coarse_image_t0.shape[0] - self.fine_image_t0.shape[0]) / 2
        N = self.fine_image_t0.shape[0]
        
        values = []
        pred_img_bands = []
        old_var_img_bands = []

        args_p = []
        # optimization process for each band
        with Pool() as pool:
            img_bands = Manager().dict()
            opt_params = Manager().dict()
            print()
            for band_num in range(min(self.coarse_image_t0.shape[2], self.fine_image_t0.shape[2])):

                kwargs = {  
                    "coarse_image" : self.coarse_image_t0[:, :, band_num],
                    "fine_image" : self.fine_image_t0[:, :, band_num].reshape(1, N * N),
                    "edge" : edge,
                    "N" : N,
                    "n_components" : n_components
                }

                optimizer_params = {}
                optimizer_params["bounds"] = bounds
                optimizer_params["kwargs"] = kwargs
                optimizer_params["iterations"] = iterations
                optimizer_params["variant"] = variant
                
                args_p.append((band_num, opt_params, img_bands,optimizer_params, evaluation, optimizer))

            results = pool.starmap(self.process_band_fusion, args_p)

            pool.close()
            pool.join()
            
            # Get the pred bands in a list
            for band_num in range(min(self.coarse_image_t0.shape[2], self.fine_image_t0.shape[2])):
                pred_img_bands.append(img_bands[band_num])
                values.append(opt_params[band_num])            

        return values, pred_img_bands


if __name__ == "__main__":

    fusion_test = IHISTIF("/home/raashika/Desktop/extrasas/imageFusionTest/imageFusion/coarse_t0.tif", "/home/raashika/Desktop/extrasas/imageFusionTest/imageFusion/coarse_t1.tif", "/home/raashika/Desktop/extrasas/imageFusionTest/imageFusion/fine_t0.tif", file_type = "geotiff")
    parameters = [[2, 15], [2, 15], [-10, 10], [-10, 10], [1, 10]]
    params,image = fusion_test.fusion(parameters, 2)
    import tifffile as tiff
    from PIL import Image
    import cv2
    
    # image = np.array(image)
    # np.save("file.npy", image)
    final_image = image[0].reshape(image[0].shape[0], image[0].shape[1], 1)

    for i in range(1, 3):
        final_image = np.dstack((final_image, image[i].reshape(image[i].shape[0], image[i].shape[1], 1)))
    
    print(final_image.shape)
    img = Image.fromarray(final_image, "RGB")
    # img.save("band_0.png")

    img.save("/home/raashika/Desktop/finet1.tif")
    tiff.imwrite('/home/raashika/Desktop/fused.tiff', image, bigtiff=True, photometric='rgb', planarconfig='separate', predictor=True, metadata={'axes': 'TZCYX'})
    
    # import imageio
    # imageio.imwrite('test_image.jpg', final_image[:, :, :])
    #
    # from matplotlib import pyplot as plt
    #
    # plt.imshow(final_image[:, :, :3])
    # plt.savefig("final_img.png")
    #
    # for bands in range(len(image)):
    #     plt.imshow(image[bands])
    #     plt.savefig(f'saved_figure_{bands}.png')