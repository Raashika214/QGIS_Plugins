import numpy as np
from fusion import IHISTIF
from dataReader import DataReader
import pandas as pd
from sklearn.metrics import mean_squared_error
from dataWriter import DataWriter
import math

np.random.seed(100)

result_file = "results-multi-res-10-20-second-quality.txt"

class Evaluator:
    """
    For evaluation of different versions and variants of the algorithm
    """
    def __init__(self, coarse_t0, coarse_t1, fine_t0, fine_t1, file_type = "geotiff"):
        """
        Initialize with the file reading and fusion process
        """

        self.fusionpProcessor = IHISTIF(coarse_t0, coarse_t1, fine_t0, file_type)

        if(file_type == "geotiff"):
            """
            File Reading for GeoTIFF files
            """
            self.fine_image_t1 = DataReader().read_geotiff_file(fine_t1)

        if(file_type == "tiff"):
            """
            File Reading for TIFF files
            """
            self.fine_image_t1 = DataReader().read_tiff_file(fine_t1)

        if(file_type == "numpy"):
            """
            File Reading for numpy files
            """
            self.fine_image_t1 = DataReader().read_numpy_file(fine_t1)

    def find_cc(self, observed, predicted):
        """
        Finding Correlation Coefficient
        Args:
            observed (_numpy_arr_): _Numpy array of ground truth image_
            predicted (_numpy_arr_): _Numpy array of predicted image_

        Returns:
            _list_: _Values for each band_
        """

        band_wise_data = []

        for band in range(min(observed.shape[2], predicted.shape[2])):
            x_band = pd.Series(observed[:, :, band].flatten())
            y_band = pd.Series(predicted[:, :, band].flatten())
            band_wise_data.append(x_band.corr(y_band))
            
        return band_wise_data

    def find_rmse(self, observed, predicted):
        """Finding Root Mean Square Error
        Args:
            observed (_numpy_arr_): _Numpy array of ground truth image_
            predicted (_numpy_arr_): _Numpy array of predicted image_

        Returns:
            _list_: _Values for each band_
        """

        band_wise_error = []

        for band in range(min(observed.shape[2], predicted.shape[2])):
            band_wise_error.append(math.sqrt(mean_squared_error(observed[:, :, band], predicted[:, :, band])))
            
        return band_wise_error

    def find_mean_absolute_difference(self, observed, predicted):
        """Finding Mean Absolute Difference
        Args:
            observed (_numpy_arr_): _Numpy array of ground truth image_
            predicted (_numpy_arr_): _Numpy array of predicted image_

        Returns:
            _list_: _Values for each band_
        """

        band_wise_error = []

        for band in range(min(observed.shape[2], predicted.shape[2])):
            band_wise_error.append(np.mean(abs(observed[:, :, band] - predicted[:, :, band])))
            
        return band_wise_error

    def evaluate(self, parameters, neighbours, iterations = 10, n_components = 10, optimizer = "default"):
        """
        Evaluate the algorithm using old version as benchmark
        Args:
            parameters (_list_): _List of list containing PSF and Fusion parameters_
            neighbours (_int_): _Neighbours to consider for missing pixels_
            iterations (int, optional): _Iterations to be used for optimization process_. Defaults to 10.
        """

        params, images = self.fusionpProcessor.fusion(parameters, iterations, neighbours = neighbours, evaluation = True, optimizer = optimizer, n_components = n_components)
        N = images[0][0].shape[0]
        standard_predicted = images[0][0].reshape(N, N, 1)
        istan_predicted = images[0][1].reshape(N, N, 1)
        improved_predicted = images[0][2].reshape(N, N, 1)
        

        for band in range(1, len(images)):
            standard_predicted = np.dstack((standard_predicted, images[band][0].reshape(N, N, 1)))
            istan_predicted = np.dstack((istan_predicted, images[band][1].reshape(N, N, 1)))
            improved_predicted = np.dstack((improved_predicted, images[band][2].reshape(N, N, 1)))

        cc_values_old = self.find_cc(self.fine_image_t1, standard_predicted)
        cc_values_changed = self.find_cc(self.fine_image_t1, istan_predicted)
        cc_values_new = self.find_cc(self.fine_image_t1, improved_predicted)

        rmse_values_old = self.find_rmse(self.fine_image_t1, standard_predicted)
        rmse_values_changed = self.find_rmse(self.fine_image_t1, istan_predicted)
        rmse_values_new = self.find_rmse(self.fine_image_t1, improved_predicted)

        mabs_values_old = self.find_mean_absolute_difference(self.fine_image_t1, standard_predicted)
        mabs_values_changed = self.find_mean_absolute_difference(self.fine_image_t1, istan_predicted)
        mabs_values_new = self.find_mean_absolute_difference(self.fine_image_t1, improved_predicted)

        if(max(mabs_values_new) < 200):
            self.display_result("Correlation Coefficient", cc_values_old, cc_values_changed, cc_values_new)
            self.display_result("RMSE", rmse_values_old, rmse_values_changed,rmse_values_new)
            self.display_result("Mean Absolute Difference", mabs_values_old, mabs_values_changed, mabs_values_new)

        return standard_predicted, istan_predicted, improved_predicted


    def display_result(self, param_name, old_values, changed_values, new_values):
        """
        Display result in tabular form
        Args:
            param_name (_string_): _Name of the parameter_
            old_values (_list_): _values from the old version of algorithm_
            new_values(_list_): _values from the updated version of algorithm_
        """

        f = open(result_file, "a")
        f.write(f"============= RESULT FOR {param_name} =================================== \n")
        f.write("||     Band     ||     HISTIF     ||     IHISTIF     ||    NEW VERSION     ||\n")
        f.write("===========================================================================\n")
        
        for id in range(len(new_values)):
            f.write(f"||     B{id}     ||     {np.round(old_values[id], 4)}     ||     {np.round(changed_values[id], 4)}     ||     {np.round(new_values[id], 4)}   ||\n")

        f.write("=========================================================================== \n")
        f.close()
        
if __name__ == "__main__":

    import os
    folder_names = os.listdir("Tests/Mult-Resolution-Fusion-3")
    folder_names = [folder for folder in folder_names if os.path.isdir(f"Tests/Mult-Resolution-Fusion-3/{folder}")]
    folder_names = sorted(folder_names)
    for dates in range(len(folder_names)):
        for second_date in range(dates + 1, len(folder_names)):
            
            coarse_t0_path = f"Tests/Mult-Resolution-Fusion-3/{folder_names[dates]}/coarse_20m.tif"
            coarse_t1_path = f"Tests/Mult-Resolution-Fusion-3/{folder_names[second_date]}/coarse_20m.tif"
            fine_t0_path = f"Tests/Mult-Resolution-Fusion-3/{folder_names[dates]}/fine_10m.tif"
            fine_t1_path = f"Tests/Mult-Resolution-Fusion-3/{folder_names[second_date]}/fine_10m.tif"

            f = open(result_file, "a")
            f.write(f"======== Evals for date {folder_names[dates]} and {folder_names[second_date]} ======== \n")
            f.close()
            evaluator = Evaluator(coarse_t0_path, coarse_t1_path, fine_t0_path, fine_t1_path)
            
            optimizer = ["default"]
            
            for func in optimizer:
                
                # scale_factor = (evaluator.fusionpProcessor.coarse_image_t0.shape[0] - evaluator.fusionpProcessor.fine_image_t0.shape[0])//2
                scale_factor = 2
                iterations = 100
                num_comp = 100

                parameters = [
                    [np.fix(scale_factor / 2), np.round_(scale_factor * 2.5)],
                    [np.fix(scale_factor / 2), np.round_(scale_factor * 2.5)],
                    [-scale_factor + 1, scale_factor-1],
                    [-scale_factor + 1, scale_factor-1],
                    [2, 10]
                ]

                print(parameters)

                f = open(result_file, "a")
                f.write(f"======== Evals for optimizer {func} ======== \n")
                f.close()

                standard_predicted, istan_predicted, improved_predicted = evaluator.evaluate(parameters, 4, iterations = iterations, n_components = num_comp, optimizer = func)
                
                standard_writer = DataWriter(standard_predicted, f"Tests/Mult-Resolution-Fusion-3/HISTIF_{folder_names[dates]}_{folder_names[second_date]}.tif").store_geotiff_file(fine_t1_path)
                istan_writer = DataWriter(istan_predicted, f"Tests/Mult-Resolution-Fusion-3/IHISTIF_{folder_names[dates]}_{folder_names[second_date]}.tif").store_geotiff_file(fine_t1_path)
                improved_writer = DataWriter(improved_predicted, f"Tests/Mult-Resolution-Fusion-3/New-Pred-{folder_names[dates]}_{folder_names[second_date]}.tif").store_geotiff_file(fine_t1_path)

                f = open(result_file, "a")
                f.write(f"======== Evals for optimizer {func} completed ======== \n")
                f.close()

                print(f"Results for Optimizer {func} completed \n")
            
            f = open(result_file, "a")
            f.write(f"======== Evals for date {folder_names[dates]} and {folder_names[second_date]} completed======== \n")
            f.close()
