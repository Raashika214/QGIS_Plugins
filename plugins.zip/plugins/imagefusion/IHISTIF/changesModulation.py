import numpy as np
# from dataWriter import DataWriter

class ChangesModulation:
    """
    For applying temporal modulation on the final images
    """        

    def multiplicativeModulation(self, coarse_t0_psf, coarse_t1_psf, fine_t0, variant = 'old', coarse_t0_psf_mod = None):
        """
        Responsible for applying multiplicativeModulation (Applying modulation changes from coarse t0 to t1)

        Args:
            coarse_t0_psf (_numpy_arr_): _Coarse T0 after applying PSF_
            coarse_t1_psf (_numpy_arr_): _Coarse T1 after applying PSF_
            fine_t0 (_numpy_arr_): _Fine T0_
            variant (str, optional): _Variant to use for modulation "new" accounts for error_. Defaults to 'old'.
            coarse_t0_psf_mod (_numpy_arr_, optional): _Used in only new varaint, modified psf applied to coarse t0_. Defaults to None.

        Returns:
            _numpy_arr_: _Predicted FIne t1 image_
        """

        if(variant == 'new'):
            # For new varaint find the error because of change in parameters
            fine_t0_predicted  = np.multiply(np.divide(coarse_t0_psf_mod, coarse_t0_psf), fine_t0)
            error = fine_t0 - fine_t0_predicted

        else:
            error = 0

        # Modulate the changes by multiplicative term and add the error
        fine_t1_predicted = np.multiply(np.divide(coarse_t1_psf, coarse_t0_psf), fine_t0) + error
        return fine_t1_predicted


    def svm_modulation(self, coarse_t0_psf, coarse_t1_psf, fine_t0, variant = 'old', coarse_t0_psf_mod = None):

        from sklearn.linear_model import LinearRegression, BayesianRidge, SGDRegressor
        from sklearn.neural_network import MLPRegressor
        from sklearn.svm import SVR
        from sklearn.ensemble import AdaBoostRegressor
        from sklearn.kernel_ridge import KernelRidge
        from sklearn.ensemble import GradientBoostingRegressor
        from sklearn.ensemble import VotingRegressor
        from xgboost import XGBRegressor
        from skimage.transform import resize
        import lightgbm as ltb

        complete_image = self.multiplicativeModulation(coarse_t0_psf.reshape(1, fine_t0.shape[1] ** 2), coarse_t1_psf.reshape(1, fine_t0.shape[1] ** 2), fine_t0.reshape(1, fine_t0.shape[1] ** 2), variant = 'old', coarse_t0_psf_mod = coarse_t0_psf_mod).reshape(fine_t0.shape[0], fine_t0.shape[1])


        downscaled_coarse_t0 = resize(coarse_t0_psf, (coarse_t0_psf.shape[0] // 2, coarse_t0_psf.shape[1] // 2))
        downscaled_fine_t0 = resize(fine_t0, (fine_t0.shape[0] // 2, fine_t0.shape[1] // 2))

        fine_t1_predicted = np.zeros((fine_t0.shape[0], fine_t0.shape[1]))

        flattened_coarse_t0 = coarse_t0_psf.flatten().reshape(-1, 1)
        flattened_fine_t0 = fine_t0.flatten()
        flattened_coarse_t1 = coarse_t1_psf.flatten().reshape(-1, 1)

        # complete_regressor = ltb.LGBMRegressor(n_jobs = 5)
        # complete_regressor.fit(flattened_coarse_t0, flattened_fine_t0)
        # predicted_flattend_img = complete_regressor.predict(flattened_coarse_t1)
        # predicted_flattend_img = np.array(predicted_flattend_img).reshape(fine_t0.shape[0], fine_t0.shape[1])

        # import tensorflow as tf
        # if(len(tf.config.experimental.list_physical_devices('GPU')) > 0):
        #     new_xgb_regressor = XGBRegressor(tree_method = "gpu_hist")
        # else:
        #     print("No GPU Found !")
        #new_xgb_regressor = XGBRegressor()
        new_xgb_regressor = MLPRegressor(hidden_layer_sizes=(300, 300), max_iter=100, activation='relu', solver='adam', verbose=True, n_iter_no_change=20, tol=1e-5, learning_rate = 'adaptive')
        new_xgb_regressor.fit(flattened_coarse_t0, flattened_fine_t0)
        #new_xgb_regressor.fit(np.concatenate((flattened_coarse_t0, downscaled_coarse_t0.reshape(-1, 1))), np.concatenate((flattened_fine_t0, downscaled_fine_t0.flatten())))
        predicted_flattend_img_xgb = new_xgb_regressor.predict(flattened_coarse_t1)

        # if(len(tf.config.experimental.list_physical_devices('GPU')) > 0):
        #     xgb_downscaled_Regressor = XGBRegressor(tree_method = "gpu_hist")
        # else:
        #     print("No GPU Found !")
        # xgb_downscaled_Regressor = MLPRegressor(hidden_layer_sizes=(100, 100), max_iter=50, activation='relu', solver='adam', verbose=True, n_iter_no_change=30, tol=1e-4, learning_rate = 'adaptive')
        # xgb_downscaled_Regressor.fit(downscaled_coarse_t0.reshape(-1, 1), downscaled_fine_t0.flatten())
        # predicted_flattend_img_xgb_downscaled = xgb_downscaled_Regressor.predict(flattened_coarse_t1).reshape(fine_t0.shape[0], fine_t0.shape[1])
        predicted_flattend_img_xgb = np.array(predicted_flattend_img_xgb).reshape(fine_t0.shape[0], fine_t0.shape[1])

        print("Image predicted")

        temporal_changes = coarse_t1_psf - coarse_t0_psf
        final_changes = np.zeros((fine_t0.shape[0], fine_t0.shape[1]))
        predicted_lc_img = np.zeros((fine_t0.shape[0], fine_t0.shape[1]))

        window_size = 5
        for i in range(fine_t0.shape[0]):
            for j in range(fine_t0.shape[1]):
                first_window = predicted_flattend_img_xgb[max(0, i - window_size): min(fine_t0.shape[0], i + window_size), max(0, j - window_size): min(fine_t0.shape[1], j + window_size)]
                #second_window = predicted_flattend_img_xgb_downscaled[max(0, i - window_size): min(fine_t0.shape[0], i + window_size), max(0, j - window_size): min(fine_t0.shape[1], j + window_size)]
                third_window = fine_t0[max(0, i - window_size): min(fine_t0.shape[0], i + window_size), max(0, j - window_size): min(fine_t0.shape[1], j + window_size)]
                actual_Window = coarse_t1_psf[max(0, i - window_size): min(fine_t0.shape[0], i + window_size), max(0, j - window_size): min(fine_t0.shape[1], j + window_size)]
                change_first = np.sum(np.abs(first_window - actual_Window)) /  (np.sum(np.abs(third_window - actual_Window)) + np.sum(np.abs(first_window - actual_Window)))
                #change_second = np.sum(np.abs(second_window - actual_Window))
                change_third = np.sum(np.abs(third_window - actual_Window)) / (np.sum(np.abs(first_window - actual_Window)) + np.sum(np.abs(third_window - actual_Window)))

                sigma_first = 1 / (1 + np.exp(-change_first))
                #sigma_second = 1 / (1 + np.exp(-change_second))
                sigma_third = 1 / (1 + np.exp(-change_third))

                weight_first = sigma_third / (sigma_first + sigma_third)
                # weight_second = sigma_second / (sigma_first + sigma_third)
                weight_third = sigma_first / (sigma_first + sigma_third)

                predicted_lc_img[i, j] = weight_first * predicted_flattend_img_xgb[i, j] + weight_third * fine_t0[i, j]

        
        predicted_flattend_img_xgb = predicted_lc_img
        
        for i in range(fine_t0.shape[0]):
            for j in range(fine_t0.shape[1]):
        #         print(i, j)

        #         regressor = SVR()
                train_data_X = coarse_t0_psf[max(0, i - window_size) : min(fine_t0.shape[0], i + window_size), max(0, j - window_size) : min(fine_t0.shape[1], j + window_size)]
                train_data_Y = fine_t0[max(0, i - window_size) : min(fine_t0.shape[0], i + window_size), max(0, j - window_size) : min(fine_t0.shape[1], j + window_size)]
                test_data_Y = coarse_t1_psf[max(0, i - window_size) : min(fine_t0.shape[0], i + window_size), max(0, j - window_size) : min(fine_t0.shape[1], j + window_size)]
                lc_change_window = predicted_flattend_img_xgb[max(0, i - window_size) : min(fine_t0.shape[0], i + window_size), max(0, j - window_size) : min(fine_t0.shape[1], j + window_size)]
                pc_change_window = complete_image[max(0, i - window_size) : min(fine_t0.shape[0], i + window_size), max(0, j - window_size) : min(fine_t0.shape[1], j + window_size)]
                
                net_change_pc = np.sum(np.abs(pc_change_window - test_data_Y)) / (np.sum(np.abs(pc_change_window - test_data_Y)) + np.sum(np.abs(lc_change_window - test_data_Y)))
                net_change_lc = np.sum(np.abs(lc_change_window - test_data_Y)) / (np.sum(np.abs(lc_change_window - test_data_Y)) + np.sum(np.abs(pc_change_window - test_data_Y)))
                net_change_nc = np.sum(np.abs(train_data_Y - test_data_Y))
                
                sigma_pc = 1 / (1 + np.exp(-net_change_pc))
                sigma_lc = 1 / (1 + np.exp(-net_change_lc))
                # sigma_nc = 1 / (1 + np.exp(-net_change_nc))

                weight_pc = sigma_lc / (sigma_pc + sigma_lc)
                weight_lc = sigma_pc / (sigma_pc  + sigma_lc)
                # weight_nc = sigma_nc / (sigma_pc + sigma_nc + sigma_lc)

                fine_t1_predicted[i, j] = weight_pc * predicted_flattend_img_xgb[i, j] + weight_lc * complete_image[i, j]



                # # train_downscaled_X = downscaled_coarse_t0[max(0, i//2 - window_size // 2) : min(fine_t0.shape[0], i//2 + window_size // 2), max(0, j//2 - window_size // 2) : min(fine_t0.shape[1], j//2 + window_size // 2)].reshape(-1, 1)
                # # train_downscaled_Y = downscaled_fine_t0[max(0, i//2 - window_size // 2) : min(fine_t0.shape[0], i//2 + window_size // 2), max(0, j//2 - window_size // 2) : min(fine_t0.shape[1], j//2 + window_size //2 )].flatten()
                

                # # train_data_X = np.concatenate((train_data_X, train_downscaled_X))
                # # train_data_Y = np.concatenate((train_data_Y, train_downscaled_Y))

                
                # regressor.fit(np.array(train_data_X), np.array(train_data_Y))
                # output = regressor.predict(coarse_t1_psf[i, j].reshape(-1, 1))
                # fine_t1_predicted[i, j] = output[0]
                


        #DataWriter(predicted_flattend_img_xgb, f"Predictions/HIGHRES_MLP.tif").store_geotiff_file()
        #DataWriter(predicted_flattend_img_xgb_downscaled, f"Predictions/LOWRES_MLP.tif").store_geotiff_file()
        return fine_t1_predicted