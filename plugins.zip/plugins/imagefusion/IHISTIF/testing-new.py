import numpy as np
from PIL import Image

# Synthesize dummy array of 40 images, each 600x600
nparr = np.random.randint(0,256,(600,600,40), dtype=np.uint8)

# Make PIL/Pillow image of first
a = Image.fromarray(nparr[:,:,0])

# Save whole lot in one TIF
a.save('multi.tif', save_all=True, append_images=[Image.fromarray(nparr[:,:,x]) for x in range(1,40)]) 