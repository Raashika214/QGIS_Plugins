import os
import cv2
import copy
import scipy.misc
from time import time
from geotiff import GeoTiff as gt
import tensorly as tl
import numpy as np
import pandas as pd
from numba import jit
from tensorly import random

from matplotlib import pyplot as plt
import pylab

pylab.rcParams['figure.figsize'] = (10.0, 8.0)

# Importing our image completion algorithms and helper functions
from .algos import *
from .helpers import *
from .UIhandler import *


class Imputation:
    def __init__(self, image, tensor_rank_estimate=12):
        '''
            Imputes missing data in a given tif file.
            tensor_rank_estimate: Estimate for tensor rank.
        '''
        try:
            # self.input_file = pd.read_csv(input_file, sep='\t')
            # self.img, self.pts_arr = df2np(self.input_file)
            # if type(image) == pd.DataFrame:
            #     self.dataframe = dataframe
            #     self.img, self.pts_arr = df2np(dataframe)
            
            self.img = image

        except:
            raise Exception("Invalid input")

        self.imSize = self.img.shape
        self.tensor_rank_estimate = int(tensor_rank_estimate)
        self.auxilary_arr_for_cmtf = None
        self.hil_mask = None  # Human-in-Loop mask
        self.current_mask = None  # m1
        self._corrupt_img = None  # must be unmodifiable
        self.imputedArray = None

        self.is_imputation_done = False
        self.brightness_param = 1.0
        self.fixed_img_np = None  # fixed image after imputation
        self.fixed_img_df = None  # fixed image df after imputation
        self.algo_runtime = []  # list to keep track of runtime for each algo
        # self.geotrans = self.dataset.GetGeoTransform()
        # self.projection = self.dataset.GetProjection()

        self.hal = None
        self.sil = None
        self.cmtf = None
        self.cpals = None
        self.cmsi = None

        self.algo_runtimes = []  # list to keep track of runtime for each algo
        self.visualization_arr = []  # list to keep track of visualization for each algo

    def get_corrupt_img(self):
        if self._corrupt_img is not None:
            return copy.deepcopy(self._corrupt_img)
        else:
            return None

    def set_corrupt_img(self, value):
        self._corrupt_img = copy.deepcopy(value)

    def set_brightness(self, value):
        self.brightness_param = value

    def draw_mask(self):
        '''
            def: Generates a rectangular/hand drawn mask for the image
            using manual user input.
        '''
        if self.get_corrupt_img() is None:
            self.set_corrupt_img(self.img)

        # consider only the first 3 layers,
        # otherwise OpenCV throws errors

        # preprocessed_img = self.get_corrupt_img().astype(np.float32)
        # print("preprocessed_img.shape",preprocessed_img.shape)
        # preprocess_img = self.get_corrupt_img()
        # preprocess_img = preprocess_img[:,:,0:3]

        # preprocessed_img /= np.max(preprocessed_img[:,:,0:3])
        # # preprocessed_img *= 255

        imgdm = copy.deepcopy(self.get_corrupt_img())
        imgdm = np.array(imgdm[:, :, :3] * self.brightness_param)

        _, inv_mask = drawMask(imgdm)

        inv_mask = np.array(inv_mask)
        ivx = (inv_mask == 255)
        ivx = np.array(ivx, dtype=bool)
        ivx = ~ivx

        self.current_mask = ivx
        self.set_corrupt_img(mask_on_img(copy.deepcopy(self.img), self.current_mask))

        return self.current_mask, self._corrupt_img

    def generate_mask(self, approximate_mask=False, threshold_value=0.1):
        '''
            def: Generates a mask for the image.
            @args threshold_value: The threshold value for the mask,
            depends completely on the dataframe
            We detect a mask by identifying outlier pixels and dead pixels
            The exact_masker works only where the missing pixels are all 0s.
        '''
        if self.get_corrupt_img() is None:
            self.set_corrupt_img(self.img)
        if approximate_mask:
            # approximate, neighbour-based masker
            self.current_mask = masker(self.get_corrupt_img(), threshold_value)
        else:
            # masks only if values in all bands are 0.
            self.current_mask = exact_masker(self.get_corrupt_img())

        return self.current_mask

    def synthetic_mask(self, fraction_to_keep=0.7):
        '''
            def: Generates a synthetic mask for the image.
        '''
        corrupt_img_output, perfect_mask = randomDelete(self.img, fraction_to_keep)
        self.set_corrupt_img(corrupt_img_output)
        self.current_mask = perfect_mask

        return self.current_mask

    def impute(self, algo, mask, speed="fast", hil = 0, hil_param = 25, tol=1e-4):
        '''
            def: Imputes missing data in a given dataframe.
            @args speed: "slow"/"fast"(default), speed of the algorithm
            @args visualize: bool (default False) to determine whether to
                             visualize the output.
        '''
        # siLRTC Implementation
        print('selected algorithm : ', algo)

        # Defining constants for (Ha/Si)LRTC algo

        a = abs(np.random.rand(self.imSize[-1], 1))
        a = a / np.sum(a)
        b = abs(np.random.rand(self.imSize[-1], 1)) / 200

        self.current_mask = np.array(mask, dtype=bool)
        self.set_corrupt_img(mask_on_img(copy.deepcopy(self.img), self.current_mask))

        self.auxilary_arr_for_cmtf = self.get_corrupt_img()[:, :, 0]

        img_orig = copy.deepcopy(self.get_corrupt_img())

        #--------------------------------------------------------------
        if hil != 0:
            ### HiL MASK MAKER CODE --------------------

            imgdummy = copy.deepcopy(self.get_corrupt_img())
            imgdummy = np.array(imgdummy[:,:,:3]*self.brightness_param)
            # Draw a HiL mask. Use 'o'/'p' to zoom in/out, LMB to draw.
            Zt,Z = drawMask(imgdummy)
            Z = np.array(Z, dtype=float)
            temp_mask = (Z == 255) # [FIX] this value is hardcoded in UIhandler.py
            imputation_val = np.average(self.get_corrupt_img()).astype('float')
            print("Imputation val = ",imputation_val)
            Z[temp_mask] = imputation_val

            self.hil_mask = self.get_corrupt_img()[:,:,0] * self.current_mask + Z * ~self.current_mask

            ### end HiL MASK MAKER CODE ----------------

        #------------------------------------------------
        itx = {"hal": 0, "sil": 0, "cmtf": 200, "cp": 200, "si": 1}

        # typically needed only when the percentage of missing pixels is
        # more than 40-50%
        if speed == "slow":
            itx = {"hal": 60, "sil": 60, "cmtf": 400, "cp": 400, "si": 1}

        if hil:
            if hil == 2:
                itx = { "hal": 0, "sil": 0, "cmtf": 1, "cp": 1, "si": 1}
            itx["si"] = 400 if speed == "slow" else 200
        else:
            self.hil_mask = self.auxilary_arr_for_cmtf

        #---------------------------------------------------------

        if algo == 'siLRTC':
            print(algo)
            if speed == "slow":
                sil = 60
            else:
                sil = 30
            print('sil iters ', sil , itx['sil'])
            self.algo_runtime.append(time())
            self.imputedArray = self.sil = siLRTC(self.get_corrupt_img(), self.current_mask, a, b, itx["sil"])
            self.algo_runtime.append(time())

        elif algo == 'haLRTC':
            if speed == "slow":
                hal = 60
            else:
                hal = 30
            print('sil iters ', hal, itx['hal'])
            self.algo_runtime = []
            self.algo_runtime.append(time())
            self.imputedArray = haLRTC(self.get_corrupt_img(), self.current_mask, a, b, itx["hal"])
            self.algo_runtime.append(time())

        elif algo == 'CMTF':
            if speed == "slow":
                cmtf_itr = 400
            else:
                cmtf_itr = 200
            print('CMTF ', cmtf_itr, itx['cmtf'])
            self.algo_runtime = []
            self.algo_runtime.append(time())
            _, self.imputedArray = cmtf(self.get_corrupt_img(), [self.auxilary_arr_for_cmtf, self.auxilary_arr_for_cmtf],
                                [0, 1], self.tensor_rank_estimate, self.current_mask, tol=1e-4, maxiter=itx["cmtf"])
            print('')
            self.algo_runtime.append(time())


        elif algo == 'CP_ALS':
            if speed == "slow":
                cp = 400
            else:
                cp = 200
            print('CP ', cp, itx['cp'])
            self.algo_runtime = []
            self.algo_runtime.append(time())
            P, self.imputedArray =  cp_als(self.get_corrupt_img(), self.tensor_rank_estimate, self.current_mask, tol=1e-4, maxiter=itx["cp"], original_img = img_orig)
            print('')
            self.algo_runtime.append(time())

        elif algo == 'CMSI':
            print('cmsi iters ', itx['si'])
            self.algo_runtime = []
            self.algo_runtime.append(time())
            P, self.imputedArray = cmtf4si(self.get_corrupt_img(), [self.hil_mask,self.hil_mask], [0,1], self.tensor_rank_estimate, self.current_mask, alpha = hil_param, tol=1e-4, maxiter=itx["si"])

            self.algo_runtime.append(time())
        return self.imputedArray