import pandas as pd
import numpy as np
from .imputation import Imputation
from geotiff import GeoTiff as gt
from osgeo import gdal
# from imputer import ImputationAlgo
from .imputerNew import Imputation as ImpNew
import numpy as np
from .helpers import *

class ImputationTest:
    def __init__(self,img, brightness):
        print("reading File", img)
        if type(img) == pd.DataFrame:
            self.dataframe =  img
            self.img, self.pts_arr = df2np(self.dataframe)
        elif type(img) == str:
            self.dataframe = pd.read_csv(img, sep='\t')
            self.img, self.pts_arr = df2np(self.dataframe)
        elif type(img) == np.ndarray:
            self.img = img
        else:
            print("Invalid INPUT")

        # self.img = np.array(gt(img).read())
        self.imp = Imputation(self.img)
        self.imp.set_brightness(brightness)
        self.imp.show_img(self.imp.img)
        # print(self.img.size)
        self.visArray = []
        self.mask = None
        print("----completed-----------")

    def tifConversion(self,result,outputFileName):

        self.numBands = len(self.dataframe.columns) - 1
        points = self.dataframe[self.dataframe.columns[0]]

        # print('numpy 2 tif conversion',result.shape)
        driver = gdal.GetDriverByName('GTiff')
        output_file = driver.Create(outputFileName,result.shape[0], result.shape[1],
                            result.shape[2],
                                    gdal.GDT_Float32)
        for band_range in range(result.shape[2]):
            output_file.GetRasterBand(band_range + 1).WriteArray(result[:, :, band_range])
        # output_file.SetGeoTransform(self.dataset.GetGeoTransform())
        # output_file.SetProjection(self.dataset.GetProjection())

    def get_x_point(self,point):
        return float(point[6:-1].split()[0])

    def get_y_point(self,point):
        return float(point[6:-1].split()[1])

    def image2tsv(self,img):
        self.points = self.dataframe[self.dataframe.columns[0]]

        self.x_points = self.points.apply(self.get_x_point).unique()
        self.y_points = self.points.apply(self.get_y_point).unique()

        self.num_bands = len(self.dataframe.columns) - 1
        self.x_image_map = {}
        self.y_image_map = {}

        for i in range(len(self.x_points)):
            self.x_image_map[self.x_points[i]] = i

        for i in range(len(self.y_points)):
            self.y_image_map[self.y_points[i]] = i

        self.image = img

        self.dfArray = np.zeros((self.image.shape[0] * self.image.shape[1], self.image.shape[2]))
        for i in range(len(self.dfArray)):
            for band_num in range(self.num_bands):
                self.dfArray[i][band_num] = self.image[self.x_image_map[self.get_x_point(self.points[i])], self.y_image_map[self.get_y_point(self.points[i])], band_num]
        self.convertedDf = pd.DataFrame(self.dfArray)
        self.convertedDf.insert(0,'0',self.points)
        return self.convertedDf

    # def tsv2image1(self,tsv):
    #     points = self.dataframe[self.dataframe.columns[0]]
    #
    #     x_points = points.apply(self.get_x_point).unique()
    #     y_points = points.apply(self.get_y_point).unique()
    #
    #
    #     dfArray = np.zeros((self.corruptImg.shape[0] * self.corruptImg.shape[1], self.corruptImg.shape[2]))
    #     print(dfArray.size)
    #     for i in range(len(dfArray)):
    #         for band_num in range(self.numBands):
    #             dfArray[i][band_num] = self.corruptImg[x_image_map[get_x_point(points[i])],
    #                                                    y_image_map[get_y_point(points[i])], band_num]
    #     convertedDf = pd.DataFrame(dfArray)
    #     convertedDf.insert(0, '0', points)
    #     convertedDf.to_csv(oFileName, sep='\t', index=None)


    def createHIL(self,outputFileName):
        print("creating missing pixels")
        self.mask,self.corruptImg = self.imp.draw_mask()
        # print(self.mask.size, self.corruptImg.shape[1])
        self.imp.show_img(self.corruptImg)
        # self.tifConversion(self.corruptImg, outputFileName)
        # np.save(outputFileName,self.corruptImg)
        self.image2tsv(self.corruptImg)
        print(self.dataframe.head())
        print(self.convertedDf.head())
        self.convertedDf.columns = self.dataframe.columns
        self.convertedDf.to_csv(outputFileName,sep='\t', index=None)

    def predictHIL(self,df,status):
        # self.corruptDf = pd.read_csv(img, sep='\t')
        self.img, self.pts_arr = df2np(df)
        # self.img = np.load(img)
        self.imp.set_corput_image = self.img
        # self.imp.show_img(self.img)
        imp = ImpNew(self.img,12)
        print("--------------------------")
        if status == 0 :
            print("No previous mask")
            self.currentMask = imp.generate_mask(60)
            result = imp.impute(algo='CP_ALS', mask=self.currentMask, speed="slow",
                                tol=1e-4)
            self.imp.show_img(result)
        else:
            print("Using previous mask")
            result = imp.impute(algo='CP_ALS', mask = self.mask, speed="slow",
                            tol=1e-4)
            self.imp.show_img(result)
        print("---------")

        # impArray = self.imp.impute(speed="fast", hil=0)
        #
        # self.imp.show_img(impArray)
        #
        # # test = self.imp.get_best_np()
        #
        # self.imp.visualize()

# impTest = ImputationTest('/home/raashika/Desktop/output/fine1.tsv',0.0006)
# impTest.createHIL('images/missingPixels1.tsv')
# print("------created---------------")
# print("------predicting---------------")
# impTest.predictHIL('images/missingPixels1.tsv')
