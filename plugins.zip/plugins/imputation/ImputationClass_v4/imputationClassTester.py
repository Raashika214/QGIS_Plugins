import pandas as pd
import numpy as np
from imputation import Imputation
from geotiff import GeoTiff as gt

tifread = gt('images/fine_t0_clipped.tif')
img = np.array(tifread.read())
imp = Imputation(img)

# [IMP] need to use this function to set
# the brightness for interactive parts/visualization
imp.set_brightness(0.0006)
imp.show_img(imp.img)

imp.draw_mask()

# hil = 0->no HiL, 1->run HiL, 2->run ONLY HiL
imp.impute(speed="fast",hil=1)

test = imp.get_best_np()

imp.visualize()
